// //
// //
// // import 'package:flutter/material.dart';
// // import 'package:like_button/like_button.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// // import 'add_like_screen.dart';
// // import 'new_api_service.dart';
// // import 'new_model.dart';
// // import 'news_detalis_screen.dart';
// //
// //
// // class NewsSearchScreen extends StatefulWidget {
// //   const NewsSearchScreen({super.key});
// //
// //   @override
// //   State<NewsSearchScreen> createState() => _NewsSearchScreenState();
// // }
// //
// // class _NewsSearchScreenState extends State<NewsSearchScreen> {
// //   TextEditingController searchController = TextEditingController();
// //   List<Article>? allArticles = [];
// //   List<Article>? filteredArticles = [];
// //   String _selectedCategory = 'General';
// //   final List<String> _categories = [
// //     'General',
// //     'Business',
// //     'Technology',
// //     'Entertainment',
// //     'Health',
// //     'Science',
// //     'Sports'
// //   ];
// //
// //   void _fetchNews() async {
// //     allArticles = await NewApiService().fatchData(_selectedCategory);
// //     _filterArticles();
// //     setState(() {});
// //   }
// //
// //   void _filterArticles() {
// //     String query = searchController.text.toLowerCase();
// //     setState(() {
// //       filteredArticles = allArticles?.where((article) {
// //         return article.title?.toLowerCase().contains(query) ?? false;
// //       }).toList();
// //     });
// //   }
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     searchController
// //         .addListener(_filterArticles); // Listen to text field changes
// //   }
// //
// //   @override
// //   void dispose() {
// //     searchController.dispose();
// //     super.dispose();
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text("News Search",style: TextStyle(color: Colors.black,fontSize: 20),),
// //         bottom: PreferredSize(
// //           preferredSize: const Size.fromHeight(100.0),
// //           child: Padding(
// //             padding: const EdgeInsets.all(8.0),
// //             child: Column(
// //               children: [
// //                 TextField(
// //                   controller: searchController,
// //                   decoration: InputDecoration(
// //                     hintText: 'Search within selected category...',
// //                     border: OutlineInputBorder(
// //                         borderRadius: BorderRadius.circular(13)),
// //                     filled: true,
// //                     fillColor: Colors.white,
// //                     suffixIcon: IconButton(
// //                       icon: const Icon(Icons.search),
// //                       onPressed:
// //                       _filterArticles, // Filter articles on button press
// //                     ),
// //                   ),
// //                 ),
// //                 const SizedBox(height: 10),
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 190),
// //                   child: DropdownButtonFormField<String>(
// //                     value: _selectedCategory,
// //                     icon: const Icon(Icons.arrow_drop_down),
// //                     iconSize: 24,
// //                     elevation: 16,
// //                     style: const TextStyle(color: Colors.black),
// //                     decoration: InputDecoration(
// //                       filled: true,
// //                       fillColor: Colors.white,
// //                       hintText: "Select a category",
// //                     ),
// //                     onChanged: (String? newValue) {
// //                       if (newValue != null) {
// //                         setState(() {
// //                           _selectedCategory = newValue;
// //                         });
// //                         _fetchNews();
// //                       }
// //                     },
// //                     items:
// //                     _categories.map<DropdownMenuItem<String>>((String value) {
// //                       return DropdownMenuItem<String>(
// //                         value: value,
// //                         child: Text(
// //                           value,
// //                           style: const TextStyle(fontWeight: FontWeight.bold),
// //                         ),
// //                       );
// //                     }).toList(),
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ),
// //         ),
// //         backgroundColor: Color(0xff633748487837),
// //       ),
// //       body: filteredArticles == null || filteredArticles!.isEmpty
// //           ? const Center(
// //         child: Text(
// //           "No data available. Please select a category or search for news.",
// //           style: TextStyle(color: Colors.black, fontSize: 16),
// //           textAlign: TextAlign.center,
// //         ),
// //       )
// //           : ListView.builder(
// //         itemCount: filteredArticles?.length,
// //         itemBuilder: (context, index) {
// //           return InkWell(
// //             onTap: () {
// //               Navigator.push(
// //                 context,
// //                 MaterialPageRoute(
// //                   builder: (context) =>
// //                       NewsDetailsScreen(
// //                         image: '${filteredArticles?[index].urlToImage}',
// //                         title: '${filteredArticles?[index].title}',
// //                         source: '${filteredArticles?[index].source}',
// //                         author: '${filteredArticles?[index].author}',
// //                         content: '${filteredArticles?[index].content}',
// //                         publishedAt:
// //                         '${filteredArticles?[index].publishedAt}',
// //                         url: '${filteredArticles?[index].url}',
// //                       ),
// //                 ),
// //               );
// //             },
// //             child: Padding(
// //               padding: const EdgeInsets.all(8.0),
// //               child: Container(
// //                 height: 350,
// //                 child: Card(
// //                   child: Column(
// //                     children: [
// //                       Image.network("${filteredArticles?[index].urlToImage}"),
// //                       Text("${filteredArticles?[index].title}"),
// //                       Text("${filteredArticles?[index].source}"),
// //                       Row(
// //                         children: [
// //                           TextButton(onPressed: (){
// //                             addFavorate("${filteredArticles?[index].title}","${filteredArticles?[index].urlToImage}");
// //                             Navigator.push(context, MaterialPageRoute(builder: (context) => AddLikeScreen(),));
// //                           }, child: LikeButton(
// //                             size: 30,
// //                           ))
// //                         ],
// //                       )
// //                     ],
// //                   ),
// //                 ),
// //               ),
// //             ),
// //           );
// //
// //         },
// //       ),
// //     );
// //   }
// //
// //   Future<void> addFavorate(String title, String image)async{
// //     var prefs = await SharedPreferences.getInstance();
// //     List<String>? favourites = prefs.getStringList("favourites");
// //     if(favourites == null){
// //       favourites = [];
// //     }
// //     favourites.add("$title|$image");
// //     await prefs.setStringList("favourites", favourites);
// //     }
// // }
// import 'package:flutter/material.dart';
// import 'package:like_button/like_button.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'new_model.dart';
// import 'news_detalis_screen.dart';
//
// class NewsSearchScreen extends StatefulWidget {
//   const NewsSearchScreen({super.key});
//
//   @override
//   State<NewsSearchScreen> createState() => _NewsSearchScreenState();
// }
//
// class _NewsSearchScreenState extends State<NewsSearchScreen> {
//   TextEditingController searchController = TextEditingController();
//   List<Article>? allArticles = [];
//   List<Article>? filteredArticles = [];
//   String _selectedCategory = 'General';
//   final List<String> _categories = [
//     'General',
//     'Business',
//     'Technology',
//     'Entertainment',
//     'Health',
//     'Science',
//     'Sports'
//   ];
//
//   void _fetchNews() async {
//     allArticles = await NewApiService().fatchData(_selectedCategory);
//     _filterArticles();
//     setState(() {});
//   }
//
//   void _filterArticles() {
//     String query = searchController.text.toLowerCase();
//     setState(() {
//       filteredArticles = allArticles?.where((article) {
//         return article.title?.toLowerCase().contains(query) ?? false;
//       }).toList();
//     });
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     searchController.addListener(_filterArticles); // Listen to text field changes
//   }
//
//   @override
//   void dispose() {
//     searchController.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("News Search", style: TextStyle(color: Colors.black, fontSize: 20)),
//         bottom: PreferredSize(
//           preferredSize: const Size.fromHeight(100.0),
//           child: Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: Column(
//               children: [
//                 TextField(
//                   controller: searchController,
//                   decoration: InputDecoration(
//                     hintText: 'Search within selected category...',
//                     border: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(13)
//                     ),
//                     filled: true,
//                     fillColor: Colors.white,
//                     suffixIcon: IconButton(
//                       icon: const Icon(Icons.search),
//                       onPressed: _filterArticles, // Filter articles on button press
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 10),
//                 Padding(
//                   padding: const EdgeInsets.only(left: 190),
//                   child: DropdownButtonFormField<String>(
//                     value: _selectedCategory,
//                     icon: const Icon(Icons.arrow_drop_down),
//                     iconSize: 24,
//                     elevation: 16,
//                     style: const TextStyle(color: Colors.black),
//                     decoration: InputDecoration(
//                       filled: true,
//                       fillColor: Colors.white,
//                       hintText: "Select a category",
//                     ),
//                     onChanged: (String? newValue) {
//                       if (newValue != null) {
//                         setState(() {
//                           _selectedCategory = newValue;
//                         });
//                         _fetchNews();
//                       }
//                     },
//                     items: _categories.map<DropdownMenuItem<String>>((String value) {
//                       return DropdownMenuItem<String>(
//                         value: value,
//                         child: Text(
//                           value,
//                           style: const TextStyle(fontWeight: FontWeight.bold),
//                         ),
//                       );
//                     }).toList(),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//         backgroundColor: const Color(0xff633748487837),
//       ),
//       body: filteredArticles == null || filteredArticles!.isEmpty
//           ? const Center(
//         child: Text(
//           "No data available. Please select a category or search for news.",
//           style: TextStyle(color: Colors.black, fontSize: 16),
//           textAlign: TextAlign.center,
//         ),
//       )
//           : ListView.builder(
//         itemCount: filteredArticles?.length,
//         itemBuilder: (context, index) {
//           return InkWell(
//             onTap: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => NewsDetailsScreen(
//                     image: '${filteredArticles?[index].urlToImage}',
//                     title: '${filteredArticles?[index].title}',
//                     source: '${filteredArticles?[index].source}',
//                     author: '${filteredArticles?[index].author}',
//                     content: '${filteredArticles?[index].content}',
//                     publishedAt: '${filteredArticles?[index].publishedAt}',
//                     url: '${filteredArticles?[index].url}',
//                   ),
//                 ),
//               );
//             },
//             child: Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: Container(
//                 height: 350,
//                 child: Card(
//                   child: Column(
//                     children: [
//                       Image.network("${filteredArticles?[index].urlToImage}"),
//                       Text("${filteredArticles?[index].title}"),
//                       Text("${filteredArticles?[index].source}"),
//                       Row(
//                         children: [
//                           TextButton(
//                             onPressed: () {
//                               addFavorite(context, "${filteredArticles?[index].title}", "${filteredArticles?[index].urlToImage}");
//                             },
//                             child: LikeButton(size: 30),
//                           ),
//                           TextButton(
//                             onPressed: () {
//                               addDislike("${filteredArticles?[index].title}", "${filteredArticles?[index].urlToImage}");
//                               Navigator.push(context, MaterialPageRoute(builder: (context) => DislikeScreen()));
//                             },
//                             child: const Icon(Icons.thumb_down, color: Colors.red, size: 30),
//                           )
//                         ],
//                       )
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
//
//   Future<void> addFavorite(BuildContext context, String title, String image) async {
//     var prefs = await SharedPreferences.getInstance();
//     List<String>? favorites = prefs.getStringList("favorites");
//     if (favorites == null) {
//       favorites = [];
//     }
//     favorites.add("$title|$image");
//     await prefs.setStringList("favorites", favorites);
//
//     LikeModel likedArticle = LikeModel(title: title, imageUrl: image);
//     //
//     // Navigator.push(
//     //   context,
//     //   MaterialPageRoute(
//     //     builder: (context) => AddLikeScreen(likedArticle: likedArticle),
//     //   ),
//     // );
//   }
//
//   Future<void> addDislike(String title, String image) async {
//     var prefs = await SharedPreferences.getInstance();
//     List<String>? dislikes = prefs.getStringList("dislikes");
//     if (dislikes == null) {
//       dislikes = [];
//     }
//     dislikes.add("$title|$image");
//     await prefs.setStringList("dislikes", dislikes);
//   }
// }
