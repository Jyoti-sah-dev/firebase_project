import 'package:flutter/material.dart';

class AddMapScreen extends StatefulWidget {
  const AddMapScreen({super.key});

  @override
  State<AddMapScreen> createState() => _AddMapScreenState();
}

class _AddMapScreenState extends State<AddMapScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(""),
      ),
      body: Column(

        children: [

        ],
      ),
    );
  }
}
